# Tourism-Big-Data-Analytics
A model led the development and implementation of a big data analytics project utilizing PySpark. ETL using Hadoop and Spark, data storage in HDFS and performing predictive analytics and  visualization using machine learning algorithms and Python libraries.
